# 一切只不過是藍色窗簾

圍棋AI alphago之後出現一系列深度學習的圍棋AI，人類一開始無法理解AI的下法，近年職業圍棋手有解析出ai的邏輯

每一手棋在AI眼裡只是只是勝率，為何人類可以解析出其中的邏輯


克蘇魯神話阿撒托斯是「盲目痴愚之神」，這世界只是阿撒托斯的夢境，既然盲目痴愚之神，又為何這世界是如此有物理法則的

愛因斯坦說過 "The eternal mystery of the world is its comprehensibility: The fact that it is comprehensible is a miracle." 

這句話被中文翻譯成"這宇宙最不能夠被理解的事，就是它竟然能夠被理解"

因為數學是純邏輯的世界，物理實驗是現實的現象，為何可以套上純邏輯的法則

 

因為一切只不過是藍色窗簾，這世界根本就沒有任何規則，只是大家自以為找到了一套解釋

 

---
tags:
  - [[Philosophy]]
  - [[Cthulhu]]
  - [[AI]]
  - [[Albert Einstein]]

---

