# Arcanum

---
tags:
  - [[English]]
  - [[Game]]
---

* ambition
  * a strong wish to achieve something
* concise
  * giving a lot of information clearly and in a few words; brief but comprehensive
* manner
  * a way in which a thing is done or happens
* fiery
  * consisting of fire or burning strongly and brightly
* compleat 
  * archaic spelling of complete
* occasion
  * a particular time or instance of an event.
