# 語言學觀點影片


* [練聽力該「加速」或「減速」嗎？久違的語言學觀點影片😚 // Chen Lily](https://youtu.be/9mkwwnUgCzQ)
* [學語言不是靠模仿？你學語言的觀念正確嗎？ // Chen Lily](https://youtu.be/vor6a_1hlJM)
* [如何停止翻譯？用英文思考的真相 🧠 語言學觀點分析 // Chen Lily](https://youtu.be/WxYnyqgO77M)


* [如何同時學多種語言🤔 How to learn multiple languages at the same time](https://youtu.be/7AY6N-ALUNw)

* TAP - [語言學觀點👁為何學英文99%的練習都無效 // Chen Lily](https://youtu.be/jRjBUbxQ0O0)

---
tags:
  - [[Chen Lily]]

---