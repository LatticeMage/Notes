# Knowledge

## License
This work is dual-licensed under CC-BY-SA-4.0 and MIT.
You need to use both them if you use this work.

`SPDX-License-Identifier: CC-BY-SA-4.0 AND MIT`