# Traditional AI

狀態機

Fuzzy Logic

位能/動能

A* Search

Minimax Tree

機率、貝葉斯網路

基因演算法



---
tags:
  - [[Algorithm]]
  - [[AI]]

---