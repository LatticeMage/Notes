# AI-UBI

We need a disscution based on this:


labor realize that involution is bad for personal,
because labor take more resource to learn one feild to get spefic feild job,
that is, for company, they can spend fewer salary to get better employee.

however, learning as maginal utility, that is , the long time only get few imporvemt.
If we take these back part of learning time to learn other feilds, already get 60%~80% result.

further, a person who has multi-ability can handle socity change.
otherwise, put all time in one feild is danger if socity change they lose their job.

decupling involution is good to break the world system

nowadays ai is common in many feild, such as drawing, chess, coding, cv,.....
even more, there is already exist many domain ai discoverd better than haman works.
for example, ai drawing more creative than human, ai go chess more creative than human, there a some algorithm develop by ai and never found by human.
chatgpt provides some views are creative and hard to find someone have that view.
ai finlly replaced labor and there is UBI to release human time. at the case, rest 2 days per week no longer exist. there is rest 7days per week .