# MusicXML

https://docs.microsoft.com/zh-tw/dotnet/standard/serialization/how-to-deserialize-an-object

https://docs.microsoft.com/zh-tw/dotnet/api/system.xml.serialization.xmlserializer?view=net-6.0

https://github.com/sightreader/musicxml-schemas

---
tags:
  - [[Programming]]
  - [[Music Theory]]
---
