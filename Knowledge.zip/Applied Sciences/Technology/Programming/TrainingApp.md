https://lightbot.com/

這遊戲10年前長這樣
https://www.youtube.com/watch?v=a39JDIT5HRc
