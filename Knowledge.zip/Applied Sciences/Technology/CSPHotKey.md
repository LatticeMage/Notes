# CSPHotKey


Written by teacher Minu

快捷鍵|功能
-|-
Ctrl+Shift+點選圖層 | 移動到點選的圖層
Ctrl+U | 調色面板
Ctrl+A | 全選
Ctrl+D | 取消選取
Ctrl+Z | 復原 Redo
Ctrl+Shift+Z | 取消復原 Undo
Ctrl+Y | 取消復原 Undo
Ctrl+X | 剪下 Cut
Ctrl+C | 複製 Copy
Ctrl+V | 貼上 Paste
Ctrl+T | 變形 Transform
Ctrl+Shift+T | 自由變形 Free Transform
Carl或Alt+空白鍵 | 畫面縮放 Zoom in/out
Carl+alt | 筆刷大小縮放 Brush size
Alt | 吸色 Eyedropper
C | 切換透明色
H | 畫布水平鏡射 Flip Horizontal
空白鍵 | 移動畫面 Hand
R | 畫布旋轉


---
tags:
  - [[Drawing]]
  - [[Technology]]
  
---