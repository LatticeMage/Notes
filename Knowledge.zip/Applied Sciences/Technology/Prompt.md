# Prompt

## Websites
* ★★☆☆☆ [Prompt 编写模式：如何将思维框架赋予机器](https://github.com/prompt-engineering/prompt-patterns)
* ★☆☆☆☆ [運用「深津式泛用Prompt」讓你的ChatGPT變聰明](https://h9856.gameqb.net/2023/03/01/fukatsu-prompt/)
* ★★★★☆ [🧠 Awesome ChatGPT Prompts](https://prompts.chat/)
* ★★★★☆ [PromptHero](https://prompthero.com/)
* ★★★★☆ [Learning Prompt](https://learningprompt.wiki/docs/%F0%9F%91%8B%20Welcome)
* ★★★★★ [Andrei Kovalev's Midlibrary 2.0 | Midjourney AI Styles Library | V5, V4, V3, niji]
  * MidJourney的詠唱庫  雖然因為要收費大家都跑去玩stable diffusion了

## Videos
* ★★★★★ [ChatGPT给的机会, 你能抓住吗? (自然语言编程)](https://youtu.be/KoT08Kno10A)
* ★★★☆☆ [【空罐王】教你如何使用DISCORD畫圖 #midjourney](https://youtu.be/uRapWGYNiBo)

---
tags:
  - [[Technology]]
  - [[AI]]
  - [[MoneyXYZ]]
  - [[空罐王CankingSketch]]

---