# eBook


* 版式流式不能互轉
  * 筆記轉移困難
* 電子書能解DRM的只有google, kobo, Amazon
  * 其他家皆綁app
  * 電子書app UI/UX很爛
  * app經常被登出，要連網才能看書
* 開放式系統不多
  * Hyread(台灣)
  * BOOX(對岸)
* 早期書本沒有電子版
  * 新書要看出版商有沒有代理，沒代理app買不到
* 硬體問題
  * 無法擴充硬碟
  * 價格昂貴


參考文章：[DRM=正版受害者](https://quantumnecro.blogspot.com/2021/10/drm.html)

---
tags:
  - [[Technology]]
  - [[DRM]]
  
---