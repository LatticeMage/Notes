# 資工笑話

## 
Bogosort 猴子排序法


##
https://twitter.com/codinghorror/status/506010907021828096

There are two hard things in computer science: cache invalidation, naming things, and off-by-one errors.


## AI
ChatGPT is Dunning kruger effect  
https://twitter.com/PR0GRAMMERHUM0R/status/1630070248555569154


---
tags:
  - [[in-joke]]
  - [[Engineering]]
  - [[Dunning–Kruger effect]]
  
---

