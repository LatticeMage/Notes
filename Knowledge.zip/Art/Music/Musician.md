# Musician

---
tags:
  - [[Perform]]
  - [[Instrument]]
  - [[Metal]]
  
---

## Guitar
* [Conny Berghäll - Revolution](https://youtu.be/9r9ghRna95I)
* [Trace Bundy - Patanga](https://youtu.be/3DbjT8vFpro)

---
tags:
  - [[Yuki Matsui / 松井祐貴]]
  - [[Seiji Igusa]]
  - [[Satoshi Gogo]]
  - [[petterisariola]]
  - [[Jon Gomm]]
  - [[Tommy Emmanuel]]
  - [[押尾コータロー]]
  - [[Masaaki Kishibe Guitar Channel]]
  - [[mikedawesofficial]]
  - [[Tobias Rauscher]]
  - [[Pierre Bensusan]]
  - [[Sungha Jung]]
  - [[Don Ross]]
  - [[Andy McKee]]
  - [[Chen Henry]]
  - [[Daniel Padim]]
  - [[Justin King]]
  - [[Luca Stricagnoli]]
  - [[Elena Yerevan]]
  - [[DEPAPEPE Official YouTube Channel]]
  
---

## Instrument
---
tags:
  - [[董舜文的頻道]]
  - [[Animenz Piano Sheets]]
  
---

## Metal
---
tags:
  - [[Sumerian Records]]
  - [[Jared Dines]]
  - [[Steve Terreberry]]
  - [[I Built The Sky]]
  - [[Andromida Official]]
  - [[DISMENTOPIA Taiwan]]
  
---