# Djent

## Band
* Periphery
* Animals as Leaders
* Intervals
* Born Of Osiris
  * M∆CHINE
* VEIL OF MAYA
  * Aeris 
* Sithu Aye
  * Senpai EP II: The Noticing 「先輩EPII：ザ・ノーティシング」 


## Youtuber
* Steve Terreberry
  * [If 'Djent' Was Added To The Oxford Dictionary](https://youtu.be/YTkuJ4vRQZM)
* Jared Dines
  * [Classic Metal VS Modern Metal](https://youtu.be/DyIr1VItWL8)


---
tags:
  - [[Music]]
  - [[Steve Terreberry]]
  - [[Jared Dines]]

---

