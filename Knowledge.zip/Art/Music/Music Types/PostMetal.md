# PostMetal

* Neurosis
* Isis
* Cult of Luna
* Pelican
* Russian Circles
* Rosetta
* Amenra
* Mouth of the Architect
* The Ocean

---
tags:
  - [[Music]]


---

