# Scale and Modes

[官大為：音樂家的理性和人體 iPod @TEDx溫羅汀「藝術」(TEDxWenLuoTing)](https://www.youtube.com/watch?v=hkMLzn6Gjv4)



---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---

