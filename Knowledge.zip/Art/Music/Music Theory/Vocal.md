# Vocal


## Singing

* Lip Roll 
  * https://www.youtube.com/watch?v=7A84o7wTipw
  * https://www.youtube.com/watch?v=SwX96skGakQ

## beatbox
https://www.youtube.com/watch?v=DcN0kAxFF8s

* [Kaila Mullady // Mexico city](https://www.youtube.com/watch?v=Y2t4IB_hUvk)


---
tags:
  - [[Music Theory]]
  
---
