# Bass Line


## Nonchord tone
[鄰音、經過音和倚音！](https://www.youtube.com/watch?v=_ZQUGFQZX04)
* Escape tone
* Passing tone
* Anticipation

## Bass range
[低音程限制：為什麼你不該使用電鋼琴上的移調鍵？](https://www.youtube.com/watch?v=hV7UK9O7xxs)

## Walking bass
[什麼是「12 小節藍調」？（12-bar blues）](https://www.youtube.com/watch?v=WId0K_X0MHc)
[走路低音！（Walking Bass）](https://www.youtube.com/watch?v=BBEs5ZvDPjU)
[如何寫出動感的低音線條？](https://www.youtube.com/watch?v=tQUC2_xWKl0)


---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---
