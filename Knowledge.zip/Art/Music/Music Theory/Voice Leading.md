# Voice Leading

## [Voice Leading](https://en.wikipedia.org/wiki/Voice_leading)

## [Four-part harmony](https://en.wikipedia.org/wiki/Four-part_harmony)
* [讓 Google 的人工智慧巴哈幫你配和弦！順便來聊聊四部和聲吧～](https://www.youtube.com/watch?v=HgnIJFwcyBk)
* [一部影片之內，搞懂音樂系必考的「四部和聲」題！](https://www.youtube.com/watch?v=2RGGuH14BUc)


---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---
