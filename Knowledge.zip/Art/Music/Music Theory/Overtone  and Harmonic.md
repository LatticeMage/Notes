# Overtone and Harmonic

https://en.wikipedia.org/wiki/Overtone

https://en.wikipedia.org/wiki/Harmonic_series_(music)


* [一次搞懂「泛音列」！](https://youtu.be/0iJmDhNocaQ)


---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---