# Pitch

## Sound pitch
 * [為什麼「八度」很重要，以及住在希臘的聰明男人](https://www.youtube.com/watch?v=rpZV2YO4LJA)  
 * [畢達哥拉斯怎麼找到 Do Re Mi？](https://www.youtube.com/watch?v=p6f__AYhqUA)  
 * [「狼五度」（Wolf Fifth）和不負責任的音樂學家](https://www.youtube.com/watch?v=Mf6XgBijyvQ)  
 * [中庸全音律，以及關於 Do-Sol 和 Do-Mi 的故事](https://www.youtube.com/watch?v=P-FexskXLTQ)  
 * [算盤神，以及不平均的平均律](https://www.youtube.com/watch?v=HkzHF147ZjE)  

 
---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---
