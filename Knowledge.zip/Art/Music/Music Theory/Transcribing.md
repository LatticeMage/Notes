# Transcribing

## Software Need
* Track Spilter by AI
* web downloader
* spectral analysis
* beat counter, tap bpm
* (instrument)

## Reference
* ★★★★☆ [好和弦教你彈鋼琴Cover：如何聽出任何曲子，然後編成鋼琴獨奏譜？（以《女神異聞錄5 - Butterfly Kiss》為例）](https://youtu.be/n4SqhV_2QAY)
* ★★★★★ [WaveTone](https://ackiesound.ifdef.jp/)

## Extra
* ★☆☆☆☆ [厲害的人不告訴你的祕技：用鋼琴的右踏板控制共振！](https://youtu.be/nLN8Gz9MJJs)
* ★★★☆☆ [一次搞懂「泛音列」！](https://www.youtube.com/watch?v=0iJmDhNocaQ)


---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]

---
