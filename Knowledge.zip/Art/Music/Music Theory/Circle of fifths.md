# Circle of fifths


## Circle of fifths
https://en.wikipedia.org/wiki/Circle_of_fifths



---
tags:
  - [[Music Theory]]
  
---
