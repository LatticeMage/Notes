# Interval


## [Interval](https://en.wikipedia.org/wiki/Interval_(music))
[八分鐘以內，一次搞懂音程名稱！](https://www.youtube.com/watch?v=QLDktqMxgmY)

distance of pitch

Semitone|intervals|intervals
-|-|-
0|P1|d2
1|m2|A1
2|M2|d3
3|m3|A2
4|M3|d4
5|P4|A3
6|d5|A4
7|P5|d6
8|m6|A5
9|M6|d7
10|m7|A6
11|M7|d8
12|P8|A7



---
tags:
  - [[Music Theory]]
  - [[NiceChord+ (好和弦+)]]
  
---