# Solfège

## Musical note name

## [Solfège](https://en.wikipedia.org/wiki/Solf%C3%A8ge)
[十分鐘以內，一次搞懂「唱名」、「首調」與「固定調」！](https://www.youtube.com/watch?v=cvu6A04S80U)
```
## == 𝄪
bb == ♭♭ 
# = ♯
b = ♭
```
English | Shearer system
-|-
Cbb | daw
Cb | de
C | do
C# | di
C## | dai
Dbb | raw
Db | ra
D | re
D# | ri
D## | rai
Ebb | maw
Eb | me
E | mi
E# | mai
E## | –
Fbb | faw
Fb | fe
F | fa
F# | fi
F## | fai
Gbb | saw
Gb | se
G | so
G# | si
G## | sai
Abb | law
Ab | le
A | la
A# | li
A## | lai
Bbb | taw
Bb | te
B | ti
B# | tai
B## | –

Then, the common rules
```
# -> i
i# -> ai

b -> e
eb -> aw
```


---
tags:
  - [[Music Theory]]
  
---
