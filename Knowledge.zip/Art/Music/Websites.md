# 零件
Comfort Strapp (BASS)  

# Music Sheets
https://www.gametabs.net/  
https://ichigos.com/  
http://senritsu.net/download/  
band score  
楽譜が無料！スマホ版GLNET+  
guitarlist.net/  
需要日本VPN  
使用SoftEther VPN Client  

吉他gpx譜
https://www.jitashe.org/artist/12215/

# Online Metronome
https://www.flutetunes.com/metronome/  

# 音感訓練
https://www.musictheory.net/exercises

http://online-audio-converter.com/



【Chord Tracker 】(yamaha)  
iOS App「PLAYER - Musician's music Player」

http://getjamn.com/


https://chordify.net/chords/atelier-rorona-alchemist-of-arland-ost-disc-1-track-19-father-and-mother-sakadayumi


ScoreCloud 自動產生五線譜


# 歌詞
http://www.kasi-time.com/subcat-cat-6843-1.html  
https://www.oricon.co.jp/prof/350780/lyrics/I241006/  
