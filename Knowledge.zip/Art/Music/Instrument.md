# Instrument

---
tags:
  - [[Music]]
---


## 次世代電子樂器

* seaboard
* linnstrument
* haken continuum fingerboard