# Anthropotomy


* 【Krenz】繪畫乾貨：人體通用比例
  * https://www.youtube.com/watch?v=3sXm8_-40tI


---
tags:
  - [[Drawing]]
  - [[Krenz's Artwork]]
  
---
