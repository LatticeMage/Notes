# Croquis


* pattern, 明暗邊框
  * [负基础速写入门 !新人怎么靠速写提升绘画实力](https://www.youtube.com/watch?v=qdBunZZJhXk)
* 觀察路人
  * [利用碎片时间暴增画技的微练习法2](https://www.youtube.com/watch?v=Aj1ZAV8ZwR0)
* 動態
  * [重口味才能画好人体动态？业余和专业画手练习量差距有多大？](https://www.youtube.com/watch?v=Bn3e48G55us)
  * [Figure Drawing - Gesture]https://www.youtube.com/watch?v=xbE0vYgng00
* [【速寫秘籍丨第一期】人體速寫動態太僵硬？如何掌握這些動態線](https://www.youtube.com/watch?v=sdYKz507ZAQ)



---
tags:
  - [[Drawing]]
  - [[抖抖村]]
  - [[Krenz's Artwork]]
  
---
