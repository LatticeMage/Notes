# Perspective


* 【抖抖村】现实世界到底是几点透视?
  * https://www.youtube.com/watch?v=FAMxLOnZrtc
* [球體有透視嗎？為什麼從哪個角度看都是正圓形？答案出人意料！](https://youtu.be/98Iu34l60OA)


---
tags:
  - [[Drawing]]
  - [[抖抖村]]
  - [[Krenz's Artwork]]
  - [[李永乐老师]]
  
---