# Copy


* 正確的臨摹
  * https://www.youtube.com/watch?v=GAx2YLX60_8
* 臨摹
  * https://youtu.be/kbKqIJcIUCw?t=329
* 抓型
  * https://www.youtube.com/watch?v=DUeVdI8cNPU


  
---
tags:
  - [[Drawing]]
  - [[抖抖村]]
  - [[Krenz's Artwork]]
  
---