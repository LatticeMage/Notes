# Chroma

* [抖抖村] 物理色彩
  * https://www.youtube.com/watch?v=ifGtg0AjRA8
* 【Krenz】 色彩
  * https://youtu.be/XfHLXSaYL0I?t=2269


---
tags:
  - [[Drawing]]
  - [[Color]]
  - [[抖抖村]]
  - [[Krenz's Artwork]]
  
---
