# Science YT

---
tags:
  - [[Science]]
  
---

## Philosophy
---
tags:
  - [[超級歪 SuperY]]
  
---

## Physics
---
tags:
  - [[眼见为识]]
  - [[妈咪说MommyTalk]]
  
---

## Mathematics
---
tags:
  - [[3Blue1Brown]]
  
---

## Popular Science
---
tags:
  - [[杜安調查團]]
  - [[李永乐老师]]
  - [[科学声音]]
  
---

## Technology
---
tags:
  - [[极客湾Geekerwan]]
  - [[林亦LYi]]
  - [[老石谈芯]]
  
---

## Medicine
---
tags:
  - [[黃瑽寧醫師健康講堂]]
  - [[蒼藍鴿的醫學天地]]
  
---