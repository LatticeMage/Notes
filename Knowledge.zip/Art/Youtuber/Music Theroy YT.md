# Music Theroy YT

---
tags:
  - [[Music Theroy]]
  
---

## Music Theroy
---
tags:
  - [[笑哈哈LOL]]
  - [[檸檬卷 Janet]]
  - [[NiceChord+ (好和弦+)]]
  - [[Adam Neely]]
  - [[成田工作室]]
  - [[Wen吉他誌]]
  - [[理科生讲音乐]]
  - [[Jacob Collier]]
  - [[Rick Beato]]
  
---