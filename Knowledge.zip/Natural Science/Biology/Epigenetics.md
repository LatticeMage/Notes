# Epigenetics

* 大自然的秘訣，生物多樣性
  * [Homosexuality: It's about survival - not sex  James O'Keefe](https://youtu.be/4Khn_z9FPmU)
* [智力高低、性傾向、精神疾病，一切都是基因決定好的？/ 書來面對 EP10 《基因：人類最親密的歷史》Siddhartha Mukherjee / 說書【科普、遺傳學】](https://youtu.be/x5aynJYhAXs)

---
tags:
  - [[Evolution]]
  
---
