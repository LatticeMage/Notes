# Emotion

## 
《腦筋急轉彎》（Inside Out）

## 
克蘇魯神話

##  
Lisa Feldman Barrett將情緒解釋為二維的光譜[Cultivating Wisdom: The Power Of Mood｜Lisa Feldman Barrett｜TEDxCambridge](https://youtu.be/ZYAEh3T5a80)

在[You aren't at the mercy of your emotions -- your brain creates them｜Lisa Feldman Barrett](https://youtu.be/0gks6ceq4eQ)


---
tags:
  - [[Biology]]
  - [[Psychology]]
  
---