彈力帶(resistance band)在找的時候有很多名詞 阻力帶 彈力帶 組力繩 高密度肌力鍛鍊帶 都可能是  
也可能搜到其他產品  
包含瑜珈用的小圈彈力帶 或者是單一條的  
  
基本上是找這種一圈的  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E8%BF%AA%E5%8D%A1%E8%BE%B2%E5%BD%88%E5%8A%9B%E5%B8%B6.PNG)  
要加重量非常簡單 拿兩條就疊加了  
想微增就不要從末端抓 抓的位置留一點長度 等於是把彈力帶延展更長  
(因為疫情因素基本上都缺貨)  
  
雙腳可以做的動作都能換單腳版本，大重量的話使用以下動作  
  
 **深蹲 Squat**  
我個人不喜歡掛在脖子後方 所以選這種掛在胸前的方式  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E6%B7%B1%E8%B9%B2.jpg)  
https://www.ammfitness.co.uk/information-advice/resistance-band-exercises-and-
workouts  
  
深蹲可以接著 **肩推 Overhead Press**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E8%82%A9%E6%8E%A8.jpg)  
https://www.fitcarrots.com/exercise/long-resistance-bands/shoulders-overhead-
press-with-long-resistance-band/  
  
  
**傳統硬舉 Conventional Deadlift**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E5%82%B3%E7%B5%B1%E7%A1%AC%E8%88%89.jpg)  
https://www.setforset.com/blogs/news/deadlift-with-resistance-band  
  
  
**相撲硬舉 Sumo Deadlift**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E7%9B%B8%E6%92%B2%E7%A1%AC%E8%88%89.jpg)  
https://www.setforset.com/blogs/news/deadlift-with-resistance-band  
  
  
臥推建議換用 **伏地挺身 Push-up Press**  
因為躺著臥推腳的出力是傳不到彈力帶的 所以選伏地挺身  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E8%83%B8%E6%8E%A8.jpg)  
https://www.ammfitness.co.uk/information-advice/resistance-band-exercises-and-
workouts  
  
  
**划船 Seated Row**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E5%88%92%E8%88%B9.jpg)  
https://www.ammfitness.co.uk/information-advice/resistance-band-exercises-and-
workouts  
  
  
**反向飛鳥 Reverse Fly**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E9%A3%9B%E9%B3%A5.png)  
https://hips.hearstapps.com/vidthumb/brightcove/57893f14e694aa370d8830c7/thumb_1468612374.png  
  
  
**二頭彎舉 Biceps Curl**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E4%BA%8C%E9%A0%AD.jpg)  
https://blog.fitbit.com/resistance-band-workout/  
  
  
**三頭 Tricep**  
![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/resistance%20band/%E5%BD%88%E5%8A%9B%E5%B8%B6%E4%B8%89%E9%A0%AD.jpg)  
https://gethealthyu.com/exercise/resistance-band-tricep-extension/  
匿名noreply@blogger.com0tag:blogger.com,1999:blog-5927269934949818513.post-52337843640515796622021-05-12T04:21:00.006-07:002023-03-10T04:07:44.924-08:00yes



---
tags:
  - [[Strength Training]]


---