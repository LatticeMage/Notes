# Copyright


## MIT vs GPL

Reference:  
[Revolution OS (作業系統革命)](https://www.youtube.com/watch?v=vWwvh3036Fw)

* GPL
  * Need to open source code
  * viral effect
* MIT
  * source can be close


### Problem: Android
LGPL

## CC
https://zh.wikipedia.org/wiki/%E5%89%B5%E7%94%A8CC

* BY (Attribution)
  * like Apache
* SA (ShareAlike)
  * like GPL
* CC0
  * [WTFPL](https://zh.wikipedia.org/wiki/WTFPL)

https://github.com/PosetMage/PosetMage.github.io/tree/master/Setting/Appendix/Tools

## multi-lisence
SPDX-License-Identifier

---
tags:
  - [[Programming]]
  - [[Law]]
  - [[Lisence]]
  
---