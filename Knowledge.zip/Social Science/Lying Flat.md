# Lying Flat

## [MoneyXYZ财务自由系列](https://www.youtube.com/playlist?list=PL1ta5B0mfuN2ni76kLEnRvSFVnWZzNzkY)
* ★★★★★ ["躺平"是实现财务自由的第一步](https://youtu.be/g8VgzgnskI0)
* ★★★★★ [同消费主义脱钩是实现财务自由最重要的一步-FIRE运动的核心基础](https://youtu.be/Nz4ymeHDy3M)
* ★★★☆☆ [追求财务自由五年, 我想明白了这几个道理](https://youtu.be/8yzqumXb3QA)
* ★★★☆☆ [从中国农村移民到加拿大做YouTuber, 这本书(outliers)教会我做人生的选择](https://youtu.be/CXVW_YOLbhY)
* ★☆☆☆☆ [躺平有理？絕望的韓國年輕人《我們，MZ新世代》｜韓國人為什麼｜胃酸人](https://youtu.be/K4xlZj96SvA)

##


---
tags:
  - [[胃酸人 위산맨]]
  - [[MoneyXYZ]]
  
---
