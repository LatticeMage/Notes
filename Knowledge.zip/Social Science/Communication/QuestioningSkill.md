# QuestioningSkill

* [碎碎念 提問的藝術：每個提問者都應該要注意的提問流程](https://blog.brownsugar.tw/the-art-of-asking/)
* [「大學生｜找工作」提問的藝術，如何一開口就讓人家覺得你是專業的「真正的必修學分｜yoloyuri」](https://youtu.be/au1-PNcJ2Oc)
* 舉手之勞是我的謙詞不是你的說辭


---
tags:



---