# UBI

## UBI
* 「無條件基本收入」是解決社會問題的良方，還是令社會停擺的毒藥？
  * https://www.youtube.com/watch?v=oLTgIlryIII
* 全民普發一萬可能嗎？
  * https://www.youtube.com/watch?v=5JY_k5jKkBY

## 解除貧窮
* [到底該怎麼幫乞丐？給錢是最好的方法嗎？一個實驗告訴你答案！](https://youtu.be/4EEOdlau3k4)
* 




---
tags:
  - [[Economics]]
  - [[窮奢極欲]]
  - [[超級歪 SuperY]]
---