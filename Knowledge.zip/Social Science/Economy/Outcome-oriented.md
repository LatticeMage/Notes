# Outcome-oriented

## Iku老師
* ★★★★☆[想抱怨的員工都要看！我離職台灣公司真正原因！【Iku老師】](https://www.youtube.com/watch?v=iKBGfLlRnxg)
* ★★★★☆[這些不了解，你副業賺不到錢是應該的！Iku老師](https://www.youtube.com/watch?v=ToX4aJnoiZM)
* ★★★★★[想要上課投資自己之前，你應該先這麼做！【Iku老師】](https://youtu.be/gH92fzkvHZM)
* ★★★★☆[iku老師的失敗過去大公開！我的創業經驗就是你的養分！創業經驗（上集）iku老師 影片精華](https://youtu.be/7fdVFwR0kKA)
* ★★★☆☆[老闆為什麼不鼓勵年輕人創業！Iku老師說絕對不是因為危險！創業經驗（下集）iku老師 影片精華](https://youtu.be/-EbKHfrOXzo)
* ★★★★☆[年輕人開公司一定賠錢負債？是你不懂省錢手段！iku老師 影片精華](https://youtu.be/r4zvzb7-0Us)

## 陳寗
* ★★★★★[小資族怎麼精進自己？最該投資項目的是「興趣」，還能靠它賺錢！【CC字幕＋4K】](https://youtu.be/pmF7Pa2AuJk)
* ★★★★★[別瞧不起冷門興趣！熱門反而難賺到錢？怎麼切入與經營是關鍵！【CC字幕＋4K】](https://youtu.be/pf2bL8_ihCI)

## 窮奢極欲
* ★★★★☆ [日本傳奇基金經理人的低風險未來戰略：因為光有錢，其實救不了你的未來。](https://youtu.be/c7T41eCmmVk)

## 思維咖啡
* ★★★★☆ [兩個可以拯救生活的創業家思維](https://youtu.be/5yVMIIhRWWA)

---
tags:
  - [[Economics]]
  - [[【官方】Iku老師的房間]]
  - [[Better Leaf 好葉]]
  - [[陳寗 NingSelect]]
  - [[窮奢極欲]]
  - [[思維咖啡]]

---