# All-in

in startup or investing theory, all-in is important,
because most of new business will fail, seprate resource to multi event just make major part loss and become zero.
So, research deep and all-in one good item will have most EV.

To face risk, usually need to use redunt system to deal with fail case.
however if put too much resource on redundancy will loss the EV.
for example, 60% on redundancy is too much. In usual, 5% Hedge is a common ratio.

For life, to be a risk-taker is impoartant, but it will cause fail.
However, we need to try many times to make EV generate the result.
that is, although fail much time, but the final success one will earn back all loss at previous.

This need Mental toughness.
Further, traind mental toughness in zero loss event such as roguelike games, deckbuilding games, Stochastic games, sports, compete.
After training these and final to apply in life is better.




---
tags:
  - [[Startup]]
  - [[Hedging]]
  - [[Risk-taking]]
  - [[Mental Toughness]]
  - [[Calculated risk-taking / strategic risk-taking ]]
  - [[Entrepreneurship]]
  - [[Economics]]
  - [[Sociology]]
  
---