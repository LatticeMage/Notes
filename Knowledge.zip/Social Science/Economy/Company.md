# Company

https://findbiz.nat.gov.tw/fts/query/QueryBar/queryInit.do

https://serv.gcis.nat.gov.tw/pub/cmpy/nameSearchListAction.do

---
tags:
  - [[Government]]
  - [[Economics]]
  
---