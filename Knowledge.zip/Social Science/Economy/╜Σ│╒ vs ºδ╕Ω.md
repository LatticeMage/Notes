很多人運動沒有做好防護措施 跑去運動之後受傷怪罪該運的是危險的  
  
很多人沒有搞懂自己在做什樣的樣的買賣 虧錢之後怪罪該生意只是投機  
  
很多人沒有搞懂藝術是需要思考和肌肉記憶的操作 連肌肉記憶都沒養成導致做不出好作品怪罪沒天份  
  
很多人自己沒有把知識理解到可以活用的地步 怪罪知識無用  

[![](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/0QOG9rS.png)](https://raw.githubusercontent.com/ArieAlchemieLich/ArieAlchemieLich.github.io/master/Images/0QOG9rS.png)

  

很多人喜歡放棄思考全靠運氣 再說某樣投資是賭博

以撲克來說 從職業撲克手[如何度過下風期](https://youtu.be/I6XTMluHrR4)更可以看出撲克是期望值的比賽  
  
1\. 首先你本來要是正期望值 一段期間內負期望值才可稱為下風期  
 你如果本來就是負期望值 那你再怎樣也是負期望值  
  
2\. 增進自己的牌技  
 因為撲克是期望值的比賽 提高期望值 在上風期可以贏更多 下風期可以輸更少甚至持平  
  
3\. (這點非常能展現撲克是期望值的比賽) 打更多局  
 正因為撲克是期望值的比賽 用更大母體樣本才更能反應期望值 所以下風期更該打大量牌局來提早離開下風期

匿名noreply@blogger.com0tag:blogger.com,1999:blog-5927269934949818513.post-32005543724227015932021-03-31T22:09:00.002-07:002023-03-10T04:16:27.421-08:00yes

