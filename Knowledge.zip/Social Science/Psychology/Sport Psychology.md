# Sport Psychology

* 《像冠軍一樣思考：運動心理學大師的20個思維訓練，成功從心態開始》
* 《愈動愈成功》



---
tags:
  - [[Psychology]]
  
---