# DID

---
tags:
  - [[Psychology]]
  - [[自说自话的总裁]]
  - [[維思維WeisWay]]
---

* [多重人格 (DID) 是怎麼一回事？精神分裂不是多重人格！【心理】（#CC字幕）｜維思維](https://youtu.be/zgrD_gbvoqc)
* [多重人格究竟是什麼？糖尿病、近視眼、柔韌度，為什麼多重人格還能改變肉體機能？也許多重人格來源於我們大腦中的一個神秘數據庫……｜自說自話的總裁](https://www.youtube.com/watch?v=hBu02kv9Evo)
