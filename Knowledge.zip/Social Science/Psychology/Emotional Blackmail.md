# Emotional Blackmail

---
tags:
  - [[Psychology]]
  - [[冏星人]]
---

* 【囧說書】讓沉重的愛得到喘息 《好想殺死父母》
