# Bullying

---
tags:
  - [[Psychology]]
  - [[武志红讲心理]]
---


[【武志红讲心理】什么样的人，容易霸凌别人？](https://youtu.be/W5GJ9ukT7tQ)