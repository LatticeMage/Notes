# Psychoanalysis

好想殺死父母……

---  
tags:
  - [[Psychology]]


---