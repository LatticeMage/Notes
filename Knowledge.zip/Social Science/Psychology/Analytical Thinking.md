# Analytical Thinking

* Top-down:
  * Top-down thinking
  * Divide-and-conquer
  * Deductive reasoning
* Bottom-up:
  * First principles thinking
  * Inductive reasoning

---
tags:
  - [[Philosophy]]
  
---