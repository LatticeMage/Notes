# Career Planning

## 推薦影片

[薪水3倍成長! 我的軟體工程師職涯規劃分享! 一間公司待多久? 跳槽時機? 薪資成長幅度大公開｜轉職｜程序员｜工程師 Nic](https://youtu.be/EdoyHZTfkT8)

---
tags:
  - [[在地上滾的工程師 Nic]]
  
---

