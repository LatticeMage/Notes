# Level Design

負責設計遊戲關卡，一般來說包含教學系統而且這也需要很多的UI/UX輔助。  
好的關卡設計本身就是天然的教學系統。 經典的例子就是 Valve的《傳送門》(Protal)  
任天堂在這塊一直是業界的標竿。

* 推薦書單
  * 《3D遊戲設計全攻略：遊戲機制×關卡設計×鏡頭訣竅》
* 推薦文章
  * [【遊戲開發】專題系列－《關卡設計 Level Design》 Indie-Guider](https://indie-guider.games/post/level-design/)
  * [怎麼招待你遊戲的「新手」們？](https://medium.com/that-game-designer/%E6%80%8E%E9%BA%BC%E6%8B%9B%E5%BE%85%E4%BD%A0%E9%81%8A%E6%88%B2%E7%9A%84-%E6%96%B0%E6%89%8B-%E5%80%91-f43cc4b8bb6e)
* 推薦影片
  * [【五分钟GDC系列】游戏关卡设计Blockmesh技巧](https://www.youtube.com/watch?v=fZ2ueLnpRPM)
  * [Design Club - Super Mario Bros: Level 1-1 - How Super Mario Mastered Level Design](https://youtu.be/ZH2wGpEZVgE)

---
tags:
  - [[Game Designer]]
  
---
