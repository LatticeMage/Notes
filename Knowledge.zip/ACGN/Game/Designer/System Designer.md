# System Designer
系統企劃要設計核心玩法，比如成長系統、戰鬥系統、操作系統.....  

* 推薦書單
  * 《進階遊戲設計：系統性的遊戲設計方法》
    * 老實說這本書的文筆很難懂作者在講什麼。總之他花了很大的篇幅在解釋系統和循環系統
  * 《游戲機制 — 高級游戲設計技術》
* 推薦影片  
  * [如何🦹‍♂️偷走🦹‍♀️優秀的遊戲設計？ #15堂課學會遊戲開發 🔧3玩法 #遊戲編劇做遊戲 7 ](https://youtu.be/YbygOXP07WY)  
* 推薦文章
  * [遊戲企劃必修課：如何寫好「系統企劃書」？](https://medium.com/that-game-designer/%E4%BB%80%E9%BA%BC%E6%98%AF%E4%BB%8B%E9%9D%A2%E8%A8%AD%E8%A8%88%E8%A6%8F%E7%AF%84-cab9691d381f)
  * [遊戲企劃必修課：如何設計遊戲的「核心循環」？](https://medium.com/that-game-designer/%E9%81%8A%E6%88%B2%E4%BC%81%E5%8A%83%E5%BF%85%E4%BF%AE%E8%AA%B2-%E5%A6%82%E4%BD%95%E8%A8%AD%E8%A8%88%E9%81%8A%E6%88%B2%E7%9A%84-%E6%A0%B8%E5%BF%83%E5%BE%AA%E7%92%B0-8dad19cb0f91)


### 打擊感
* [【專欄】別再揮空氣了！關於遊戲中的「打擊感」三兩事](https://gnn.gamer.com.tw/detail.php?sn=125251)
* [[設計] 絕對有爽感保證的遊戲設計](https://www.ptt.cc/bbs/GameDesign/M.1668391918.A.A33.html)
* [动作游戏打击感的来源是什么？ - 知乎](https://www.zhihu.com/question/21342866)

---
tags:
  - [[Game Designer]]
  
---
