# Game Designing

推薦影片：[國際發行商媒合會 – 獨立遊戲出海求生指南](https://youtu.be/mtObYJRb2ug?t=1900)

目前主流生產遊戲流程大概是：

TA設定、競品分析

天馬行空的發想  
* 推薦影片
  * [如何把💡靈感變成遊戲？ #15堂課學會遊戲開發 🔧1發想 #遊戲編劇做遊戲 2](https://www.youtube.com/watch?v=SdfA7NBV0fI)

將發想跟TA結合成提案  
* 推薦影片 
  * [如何講得一嘴好遊戲？ #15堂課學會遊戲開發 🔧2提案 #遊戲編劇做遊戲 4](https://youtu.be/uP2ZV-Z4CHI)
  * [30 Things I Hate About Your Game Pitch](https://youtu.be/4LTtr45y7P0)

做出Prototype

遊玩&改進prototype  
(好玩的遊戲在prototype時期就會好玩  
prototype不好玩的遊戲，基本上進入產品階段通常還是不好玩)

不好玩要捨棄，從頭開始設計一款新遊戲

開始加上美術  程式優化  手感優化

QA給完整的遊戲改善建議


---
tags:
  - [[ACGN]]
  - [[Extra Credits]]
  - [[摩訶聖 遊戲編劇聊遊戲]]
  
---
