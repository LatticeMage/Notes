# GalgameMaker

## [視覺小說引擎列表](https://zh.wikipedia.org/zh-tw/%E8%A6%96%E8%A6%BA%E5%B0%8F%E8%AA%AA%E5%BC%95%E6%93%8E%E5%88%97%E8%A1%A8)


## 免費
免費的就已經很好用了，已經涵蓋大部分需要的功能

* 吉里吉里 = krkr = KiriKiri
  * 日系古老的open source engine
  * 由於是古老的軟體，跨平台能力差
* [THE NVL Maker](https://www.nvlmaker.net/download.html)
  * 基於吉里吉里打包的介面友善版
  * 有大量的中文資源 ex:https://www.nvlmaker.net/manual/tutorial.html
* [Ren'Py](https://www.renpy.org/latest.html)
  * 擴充性強，基於python，跨平台性也好很多，有持續在更新
  * 官方文件詳盡 https://www.renpy.org/doc/html/
  

## 付費
* Visual Novel Maker
  * 沾RPG Maker名聲的，專門用來生產galgame
  * 評價：https://www.zhihu.com/question/68238029
* RPG Maker
  * 很多galgame也是用RPG Maker製作的，特別是會有一些遊戲系統



---
tags:
  - [[Galgame]]
  - [[AVG]]
  
---
